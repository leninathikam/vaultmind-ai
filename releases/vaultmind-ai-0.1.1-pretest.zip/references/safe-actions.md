# SafeAction Planner

This is an orchestration contract, not executable validation code. Enforcement belongs to registered experts and platform gates. If they cannot establish a guard, refuse the write and leave a preview.

## Plan record

Assign a session-local monotonically increasing plan version. Record goal, authorized roots, exclusions, actor, creation context, coverage and selected evidence. Enumerate each action with an action number, operation=move, exact existing source and exact proposed destination, source identity if available, SHA-256, size, rationale, source citation, collision check, risks, and inverse-operation prerequisites. Do not fabricate a platform plan ID.

Destination must be inside the authorized existing directory tree. Resolve canonical containment through file-agent; reject ambiguous aliases, symlink escapes, excluded descendants, duplicate sources, duplicate destinations, source=destination and any overwrite. A target path that is a source in another action is a conflict; no chains or cycles. No file is selected merely because it is old or possibly sensitive.

Before requesting approval, show a stable numbered before/after preview. An approval must refer to the exact plan version and action numbers. Partial approval permits only those actions. Any plan change, scope change, revoked approval, source change or destination conflict invalidates the affected approval. A generic cleanup request does not count as approval of a generated plan.

## Execution contract

1. Re-read source metadata and hash; compare against the reviewed evidence. Missing evidence blocks the operation.
2. Independently verify permissions, canonical paths, exclusions and a destination that does not exist. Require platform mechanisms to enforce no overwrite at execution time, not merely a preflight check.
3. Follow current gateway approval and Registry constraints. If atomic conflict handling or identity enforcement is unavailable, retain preview-only status.
4. Move one item at a time. Verify the new path, hash and size and the old path state. Record confirmed completion before continuing.
5. On error, cancellation or uncertain completion, stop. Separate succeeded, failed, unattempted and outcome-unknown items. Never repeat an uncertain mutation without read-back.

## Recovery

On a user request to undo, construct a new inverse move plan only for verified successful items. Confirm that the moved file is unchanged, the original path is vacant, the original parent exists, and both paths remain authorized. Show the inverse preview and seek fresh approval. The inverse remains a guarded move, not a guaranteed transaction. If any precondition fails, stop and report manual recovery requirements. Do not delete destination content to make rollback succeed.

## Audit and storage semantics

Record plan version, selected actions, user approval scope, validation failures, actual outcomes and inverse-plan links in the visible session. Optional redacted report export is separately approved. This is not tamper-proof persistent logging. Hash duplicates describe content equality, not user intent to remove a copy. Logical redundant bytes equal sum of non-keeper sizes, but physical reclaimable bytes are unknown; organization moves reclaim zero.
