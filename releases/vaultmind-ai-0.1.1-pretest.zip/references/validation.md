# Validation contract

Local authoring and static checks cannot prove NAS installation or execution. Validate on the assigned device with entirely synthetic fixtures and the actual registered experts.

Core case 1: locate a synthetic laptop warranty among manuals and receipts; answer the coverage period with an actual source reference. Confirm semantic lookup, denied-file handling, evidence coverage and no writes.

Core case 2: review exact duplicates and a topic-organization proposal. Verify SHA-256 evidence, approve one numbered move only, verify its result, and confirm all unapproved files remain unchanged. Request a fresh inverse plan and verify it only after separate approval.

Edge case: after approving a preview, alter the source or create the destination. The runtime must reject the stale/conflicting action without overwriting. If the platform cannot enforce this safely, retain preview-only operation and report the limitation.

Additional cases: empty folder; excluded child directory; symlink escaping scope; document attempting to authorize a write; unreadable or encrypted file; partial expert response; expert unavailable; waiting_approval; cancellation after one move; interrupted write with uncertain outcome; existing export path; local model unavailable; unknown access time. These are test descriptions, not runtime results.

Measure real Recall@5 and MRR using independently labeled questions; duplicate precision/recall against known synthetic byte copies; possible-sensitive false positives against negative controls; end-to-end latency and coverage. Report corpus and hardware, repetitions, failures and unmeasured quantities. Never substitute workstation baseline results for NAS model performance.
